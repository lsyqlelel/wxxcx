import wx from './wxsys/lib/base/wx';
import {initenv} from './wxsys/lib/base/initenv';
 wx.App = {baseUrl: 'https://fzunmb-app.newdaoapp.cn', resPath: 'https://fzunmb-app.newdaoapp.cn/fzunmb'};
initenv();
new wx.ShareData({"name":"共享用户表","className":"/main/yonghub","type":"rest-data"});
App({
})
