import wx from '../../../../wxsys/lib/base/wx';
import BindComponent from "../../../../wxsys/lib/base/bindComponent";
import {observable,toJS,autorun} from '../../../../wxsys/lib/mobx/mobx-2.6.2.umd';

export default class Imgshow extends BindComponent {
     constructor(page, id, props, context){
        super(page, id, props, context);
        this.fileType = [".gif",".jpeg",".jpg",".png",".svg"];
        this.actionUrl = wx.App.baseUrl + (this.props.actionUrl || "/storage");
        this.urls = observable();
        this.rows = [];
        var self = this;
        autorun(() => {
        	var value = self.getValue();
        	var rows = [];
        	if(value && value.indexOf("[{\"storeFileName\"") == 0){
        		value = JSON.parse(value);
        		for(var i = 0 ; i < value.length ; i ++){
        			var name = value[i].realFileName;
        			var type = name.substring(name.lastIndexOf("."),name.length);
        			if(this.fileType.indexOf(type) != -1 ){    				
        				const p1 = new Promise((resolve, reject) => {
        					wx.request({
        						url: this.actionUrl + '/presignedGetObject',
        						data: {
        							objectName: value[i].storeFileName
        						},
        						header: {
        							'content-type': 'application/json'
        						},
        						success: function (res) {
        							resolve(res.data);
        						}
        					})
        					
        				})
        				rows.push(p1);
        			}
        		}
        		if(rows.length > 0 ){    			
        			Promise.all(rows).then(result => {
        				var row = [];
        				self.rows = result;
        				for(var i = 0 ; i < result.length; i ++){
        					row.push({url:result[i]});
        				}
        				self.urls.set(row);
        			}
        			)
        		}else{
        			self.urls.set([]);
        		}
        	}else{
        		self.urls.set([]);
        	}	
        })
     }
     buildState(context){
     	var state = super.buildState(context);
     	state.urls = toJS(this.urls);
     	return state;
     }
     
     
     imgClick(){
     	var src = arguments[0].currentTarget.dataset.src;
     	if(src){
     		var self = this;
            wx.previewImage({
                current: src, // 当前显示图片的http链接
                urls: self.rows // 需要预览的图片http链接列表
            })
     	}
     		
     }
     calUrl(){
    	 var url =[{url:"http://img.lanrentuku.com/img/allimg/1706/46-1F6151A1040-L.jpg"},
    	           {url:"http://img0.imgtn.bdimg.com/it/u=3138365389,851751545&fm=27&gp=0.jpg"},
    	           {url:"http://img4.imgtn.bdimg.com/it/u=1742626185,2547278809&fm=27&gp=0.jpg"}];
    	 return url;
      }
}

wx.comp = wx.comp || {};
wx.comp.Imgshow = Imgshow;
