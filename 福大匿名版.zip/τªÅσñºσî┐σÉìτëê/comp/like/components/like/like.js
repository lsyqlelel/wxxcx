import wx from '../../../../wxsys/lib/base/wx';
import BindComponent from "../../../../wxsys/lib/base/bindComponent";
import Util from "../../../../wxsys/lib/base/util";
import Component from "../../../../wxsys/lib/base/component";
import {observable,toJS,autorun} from '../../../../wxsys/lib/mobx/mobx-2.6.2.umd';

export default class Like extends BindComponent{
    constructor(page, id, props, context){
        super(page, id, props, context);
        this.textCount = observable("");
        this.likeCol = observable(false);
        var self = this;
         autorun( () => {
         	if(self.getValue()){
             	self.textCount.set(self.getValue())
               }
			   self.getFidClick("init") ;
         })

         this.page.BtnClick = this.BtnClick.bind(this);
     }
    
    
    buildState(context){
	 	var state = super.buildState(context);
	    state.text = this.textCount.get();
	    state.sty = this.likeCol.get();
	 	return state;
	 }
    

	getFidClick(type){
		if(this.props.textCount){
		  var self = this ;
		  var arr = this.props.textCount.split(".");
       	  var  itemData = self.context.vars[arr[0]];
		  var fid ;
       	 if(!itemData.fid){
 		   fid = itemData.getCurrentRow().fid;
		   if(type=="init"){
                var value = wx.getStorageSync(fid);
				if(fid && value==fid) {
					self.likeCol.set(true);
				}
		   }
       	 }else{
       		fid = itemData.fid ;
			if(type=="init"){
				var value = wx.getStorageSync(fid);
			    if(value==fid && fid) {
				  self.likeCol.set(true);
			}
			}
      }
         if(type=="currentClick"){
            var value = wx.getStorageSync(fid);
           if(value !=fid) {
             console.log("可以+1");
	   	    	  var oldValue = self.textCount.get()*1;
		   	    	var  getNumb = self.textCount.get()*1 + 1;
		   	    	self.likeCol.set(true);
		   	    	self.fireEvent(Like.EVENT_VALUE_CHANGE , {source: self,oldValue:oldValue,newValue:getNumb});
		   	    	self.textCount.set(getNumb);  
           }else{
             console.log("已经点过赞了");
		   	    	  wx.showToast({
						  title: '已经点过赞了',
						  icon: 'success',
						  duration: 2000
						})
           }
		   	  wx.setStorage({
			       	  key:fid,
			       	  data:fid
		       	})
		 }

		}else{
   	    	wx.showToast({
   	    	  title: '请绑定数据集',
   	    	  icon: 'success',
   	    	  duration: 2000
   	    	})
   	     
 }
	}
    BtnClick(event){
        this.getFidClick("currentClick")
		
	
    }
   
};
Like.EVENT_VALUE_CHANGE = "valuechange";

wx.comp = wx.comp || {};
wx.comp.Like = Like;
