import wx from '../../lib/base/wx';
import BindComponent from "../../lib/base/bindComponent";

export default class Input extends BindComponent {
     constructor(page, id, props, context){
        super(page, id, props, context);
     }
     
     // 模态对话框
     showDateTimeDialog(evt){
    	 if ((evt.currentTarget.dataset.disabled==true) || (evt.currentTarget.dataset.disabled=="true")) return;
    	 var dialog = this.page.comp("__pickerViewOnce__");
    	 var self = this;
    	 var oldtime = this.getValue();
    	 dialog.showDialog(oldtime,(time)=>{
    		 var time = new Date(time);
    		 self.doChange({value: time});
    	 })
     }
     
     //重写父类的getValue方法
     getValue(){
    	 if (this.props.$refFn){
    		 return super.getValue();
    	 }else{
    		 return this._currentValue;
    	 }
     }
     
     beforeSetValue(path, prop, value, callback){
    	 return this._currentValue = value;
     }

     //----------------- 
     //为了解决bindblur在bindtap之后执行问题，在onInput中记录当前最新的值, 并把当前组件实例设置到页面上, 在bindtap中调用$updateValue
     onInput(evt){
     	this.page.$lastInput = this;
     	this._currentValue = evt.detail.value;
     }
     $updateValue(){
    		this.page.$lastInput = null;
        	this.doChange({value: this._currentValue});
     }
     //-------------------
}


Input.EVENT_VALUE_CHANGE = "valuechange";

wx.comp = wx.comp || {};
wx.comp.Input = Input;

