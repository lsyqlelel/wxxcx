import wx from '../../../lib/base/wx';
import PageImpl from "../../../lib/base/pageImpl";

export default class IndexPage extends PageImpl {
	constructor(...args){
		super(...args);
	}
}
