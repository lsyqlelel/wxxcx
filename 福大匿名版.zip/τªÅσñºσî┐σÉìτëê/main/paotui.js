
import {createPageConfig} from './paotui.build';
Page(createPageConfig());
