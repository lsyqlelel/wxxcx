import wx from '../wxsys/lib/base/wx';
import PageImpl from "../wxsys/lib/base/pageImpl";
var app = getApp();
export default class IndexPage extends PageImpl {
	constructor(...args){
		super(...args);
	}

    
    //用户表刷新后事件
    yonghuEvent(e){
        debugger;
        if(this.comp("restData1").count() == 0){
            this.comp("restData1").newData({
                "defaultValues": [{
                    "fyonghuid": this.$compRefs.restData2.current.id,
                    "fnicheng": this.$compRefs.restData2.current.nickName,
                    "ftouxiang": this.$compRefs.restData2.current.avatarUrl,
                    "fdianhua": this.$compRefs.restData2.current.phone,
                    "fyouxiang": this.$compRefs.restData2.current.email,
                    "fmingcheng": this.$compRefs.restData2.current.name
                }]
            });
            this.comp("restData1").saveData(undefined);        
        }
    }

    // dangqianEvent(e){
    //     if(this.comp('restData2').count()==0){
    //         this.comp('restData2').newData({
    //             "defaultValues": [{
    //             "fyonghuid": this.comp("restData1").getValue("fyonghuid"),
    //         }]
    //     });
    //     this.comp('restData2').saveData(undefined);
    //     }
    // }

    // yonghuguanliEvent(e){
    //     if(this.comp('restData2').count()==0){
    //         this.comp('restData2').newData({
    //             "defaultValues": [{
    //             "fyonghuid": this.comp("restData1").getValue("fyonghuid"),
    //         }]
    //     });
    //     this.comp('restData2').saveData(undefined);
    //     }
    // }

}
