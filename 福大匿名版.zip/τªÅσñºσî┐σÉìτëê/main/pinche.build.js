import wx from '../wxsys/lib/base/wx';
import _createPageConfig from '../wxsys/lib/base/createPageConfig';
import PageClass from './pinche.user';

 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


import '../wxsys/comps/wrapper/wrapper';

 var $g_fns_restData2 = {
		get _userdata(){
			return {
				data9: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data17: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data6: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data5: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				avatarUrl: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data4: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data3: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				nickName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data2: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				isLogined: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				description: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				userName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				phone: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				name: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				id: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				email: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data15: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				group: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				}
			};
		}
}; 

import '../wxsys/comps/user/user'; 
import '../wxsys/comps/image/image'; 
import '../wxsys/comps/commonOperation/commonOperation'; 
import '../wxsys/comps/list/list'; 
import '../wxsys/comps/restData/restData'; 
import '../comp/wxxcx_login/components/wxxcx_login/wxxcx_login'; 
import '../wxsys/comps/page/page'; 
import '../wxsys/comps/wrapper/wrapper'; 
import '../wxsys/comps/navbar/navbar'; 
import '../wxsys/comps/toptips/toptips'; 
import '../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $attrBindFn_text_text2: function({restData,restData1,list2index,$item,params,list2item,$page,restData2,props}){
 try{return wx.Util.iif(list2item.fhuifus!="",list2item.fhuifus,"0")}catch(e){return ''} ;
}

,
 $attrBindFn_text_text4: function({restData,restData1,list2index,$item,params,list2item,$page,restData2,props}){
 try{return wx.Util.iif(list2item.fbaomilx!="true",list2item.ffatier_yonghub_fnicheng,"匿名用户")}catch(e){return ''} ;
}

,$evtH_page_show: function({$event,$data,restData,restData1,$item,params,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"force":"true"};
	return $page.$compByCtx('restData',$event.source).executeOperation('refresh', args, $$$args);

}

,$evtH_image_tap: function({$event,$data,restData,restData1,$item,params,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/wode.w"};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('navigateTo', args, $$$args);

}

,$evtH_list2_tap: function({$event,$data,restData,restData1,list2index,$item,params,list2item,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/huifu_t.w"};
	args.params={"param0":list2item.fid};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('navigateTo', args, $$$args);

}

,$evtH_row3_tap: function({$event,$data,restData,restData1,list2index,$item,params,list2item,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/fatie/fatie.w"};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('navigateTo', args, $$$args);

}

,
 $roFn_restData2: function($data){
return true;
}

,
 $items_list2: function({restData,restData1,list2index,params,list2item,$page,restData2,props}){
 return restData.value ;
}

,$evtH_bar_tap: function({$event,$data,restData,restData1,list2index,$item,params,list2item,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/index.w"};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('navigateTo', args, $$$args);

}

,
 $filter__system1__restData1: function({isNotNull,$$dataObj,restData,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,restData2,props,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('fyonghuid',restData2.current.id/*{"dependencies":["user"]}*/, $$dataObj);
 ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"$events":{
					"afterRefresh":"yonghuEvent"
				},
				"options":{
					"depends":[
						"user"
					],
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{
					"_system1_":[
						"$filter__system1__restData1"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[
						{
							"name":"fzhidingzt",
							"type":1
						},
						{
							"name":"ffatiesj",
							"type":0
						}
					],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"_key":{
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"ffatier_yonghub_fnicheng":{
								"define":"fnicheng",
								"label":"发帖人-昵称",
								"type":"string",
								"table":"main_yonghub"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							},
							"ffatier_yonghub_fyonghuid":{
								"define":"fyonghuid",
								"label":"发帖人-用户ID",
								"type":"string",
								"table":"main_yonghub"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_yonghub",
							"columns":[
								{
									"field":"fyonghuid",
									"name":"ffatier_yonghub_fyonghuid",
									"label":"发帖人-用户ID"
								},
								{
									"field":"fnicheng",
									"name":"ffatier_yonghub_fnicheng",
									"label":"发帖人-昵称"
								}
							],
							"leftTable":"main_fatieb",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fyonghuid",
									"leftField":"ffatier"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData2",
					"type":"array",
					"items":{
						"fns":$g_fns_restData2,
						"type":"object",
						"key":"_key",
						"props":{
							"data9":{
								"readonly":"$data.getReadonly()",
								"define":"data9",
								"label":"地址",
								"type":"string"
							},
							"data17":{
								"readonly":"$data.getReadonly()",
								"define":"data17",
								"label":"生日",
								"type":"date"
							},
							"data6":{
								"readonly":"$data.getReadonly()",
								"define":"data6",
								"label":"国家",
								"type":"string"
							},
							"data5":{
								"readonly":"$data.getReadonly()",
								"define":"data5",
								"label":"微博",
								"type":"string"
							},
							"avatarUrl":{
								"readonly":"$data.getReadonly()",
								"define":"avatarUrl",
								"label":"头像",
								"type":"string"
							},
							"data4":{
								"readonly":"$data.getReadonly()",
								"define":"data4",
								"label":"QQ",
								"type":"string"
							},
							"data3":{
								"readonly":"$data.getReadonly()",
								"define":"data3",
								"label":"市",
								"type":"string"
							},
							"nickName":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"昵称",
								"type":"string"
							},
							"data2":{
								"readonly":"$data.getReadonly()",
								"define":"data2",
								"label":"省",
								"type":"string"
							},
							"isLogined":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"是否登录",
								"type":"boolean"
							},
							"description":{
								"readonly":"$data.getReadonly()",
								"define":"description",
								"label":"备注",
								"type":"string"
							},
							"userName":{
								"readonly":"$data.getReadonly()",
								"define":"userName",
								"label":"登录名",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"phone":{
								"readonly":"$data.getReadonly()",
								"define":"phone",
								"label":"手机",
								"type":"string"
							},
							"name":{
								"readonly":"$data.getReadonly()",
								"define":"name",
								"label":"姓名",
								"type":"string"
							},
							"id":{
								"readonly":"$data.getReadonly()",
								"define":"id",
								"label":"id",
								"type":"string"
							},
							"email":{
								"readonly":"$data.getReadonly()",
								"define":"email",
								"label":"邮箱",
								"type":"string"
							},
							"data15":{
								"readonly":"$data.getReadonly()",
								"define":"data15",
								"label":"性别",
								"type":"integer"
							},
							"group":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"群组",
								"type":"array"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/uaa/user",
					"autoMode":"",
					"defSlaves":[],
					"confirmDelete":true,
					"tableName":"uaa_user",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isAllColumns":true,
					"idColumn":"id"
				},
				"$roFn":"$roFn_restData2",
				"id":"restData2",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"$events":{
				"show":"$evtH_page_show"
			},
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/comp/wxxcx_login/components/wxxcx_login/wxxcx_login'),
		"props":{
			"miniappLogin":true,
			"id":"wxxcx_login",
			"mpLogin":false
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/user/user'),
		"props":{
			"useOtherLogin":false,
			"autoUpdateUserInfo":true,
			"useSmsService":true,
			"data":"restData2",
			"loginSuccessHint":true,
			"useOpenid":false,
			"autoLoadUserInfo":true,
			"id":"user",
			"autoBindPhone":false,
			"appPath":"$UI/main",
			"logoutAfterToLogin":true,
			"autoLogin":true
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/image/image'),
		"props":{
			"src":"$model/UI2/main/images/futainimingban.png",
			"id":"image"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list2",
			"item":"list2item",
			"autoRefresh":true,
			"dataId":"restData",
			"$template":[
				{
					"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
					"props":{
						"id":"text2",
						"$attrBindFns":{
							"text":"$attrBindFn_text_text2"
						}
					}
				},
				{
					"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
					"props":{
						"id":"text4",
						"$attrBindFns":{
							"text":"$attrBindFn_text_text4"
						}
					}
				}
			],
			"autoLoadNextPage":true,
			"index":"list2index",
			"id":"list2",
			"items":"restData.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/navbar/navbar'),
		"props":{
			"current":"bar",
			"id":"navbar",
			"bars":[
				"bar",
				"bar1",
				"bar2"
			]
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"bar"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"bar1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"bar2"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"篱笆闲聊","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
