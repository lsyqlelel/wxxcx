import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './fatie.user';

 var $g_fns_tableData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData2 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_tableData = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_tableData4 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_d_restData_fzhidingzt = function(){
		let $self=this;
		try{
 			return 1
		}catch(_$e){
			return null;
		}

}; 


 var $g_d_restData_ffatiesj = function(){
		let $self=this;
		try{
 			return wx.Date.now()
		}catch(_$e){
			return null;
		}

}; 


 var $g_d_restData_fhuifus = function(){
		let $self=this;
		try{
 			return 0
		}catch(_$e){
			return null;
		}

}; 


 var $g_d_restData_fbaomilx = function(){
		let $self=this;
		try{
 			return 0
		}catch(_$e){
			return null;
		}

}; 


 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';

 var $g_fns_restData3 = {
		get _userdata(){
			return {
				data9: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data17: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				country: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data5: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				gender: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				avatarUrl: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data4: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				city: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				openId: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				nickName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				isLogined: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				groups: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				description: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				userName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				province: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				phone: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				name: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				id: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				email: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				group: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				}
			};
		}
}; 

import '../../wxsys/comps/user/user'; 
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/tableData/tableData'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/input/input'; 
import '../../wxsys/comps/switch/switch'; 
import '../../wxsys/comps/button/button'; 
import '../../wxsys/comps/code/code'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/wrapper/wrapper'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/textarea/textarea'; 
import '../../wxsys/comps/attachmentImage/attachmentImage'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $refPathFn_input: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current._path ;
}

,
 $refFn_attachmentImage: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current.ftupianfj ;
}

,
 $refFn_input: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current.fbiaoti ;
}

,
 $refFn_textarea: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current.fneirong ;
}

,$evtH_button3_tap: function({$event,$data,restData,restData1,tableData,params,restData2,props,restData3,tableData4,tableData1,$item,$page}){
let $$$args = arguments[0];
wx.OperationPromise.resolve(function(){
	let args={};
	args.title="标题不能为空！";
	if (wx.Util.iif(restData.current.fbiaoti=="",true,false)) 	return $page.$compByCtx('wxapi',$event.source).executeOperation('showToast', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args.title="内容不能为空！";
	if (wx.Util.iif(restData.current.fneirong=="",true,false)) 	return $page.$compByCtx('wxapi',$event.source).executeOperation('showToast', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args.title="图片不能为空！";
	if (wx.Util.iif(restData.current.ftupianfj=="",true,false)) 	return $page.$compByCtx('wxapi',$event.source).executeOperation('showToast', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"ffatier","item":"restData.current.ffatier","data":"restData"};
	args.row=restData.current;
	args.value=restData2.current.fyonghuid;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"fbiaoti","item":"restData.current.fbiaoti","data":"restData"};
	args.row=restData.current;
	args.value=restData.current.fbiaoti;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"fneirong","item":"restData.current.fneirong","data":"restData"};
	args.row=restData.current;
	args.value=restData.current.fneirong;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"ffatiesj","item":"restData.current.ffatiesj","data":"restData"};
	args.row=restData.current;
	args.value=wx.Date.now();
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"ftupianfj","item":"restData.current.ftupianfj","data":"restData"};
	args.row=restData.current;
	args.value=restData.current.ftupianfj;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"data":"restData"};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('saveData', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args.title="发帖成功！";
	return $page.$compByCtx('wxapi',$event.source).executeOperation('showToast', args, $$$args);
}()).then(() => {
	let args={};
	args={"url":"$UI/main/wode/wode_ft.w"};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('redirectTo', args, $$$args);
});
});
});
});
});
});
});
});
});
});

}

,
 $attrBindFn_hidden_text3: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 try{return wx.Util.iif(restData.current.fbaomilx==false,false,true)}catch(e){return ''} ;
}

,
 $refFn_switch1: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current.fbaomilx ;
}

,$evtH_page_show: function({$event,$data,restData,restData1,tableData,params,restData2,props,restData3,tableData4,tableData1,$item,$page}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('page',$event.source).executeOperation('refresh', args, $$$args);

}

,
 $refPathFn_textarea: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current._path ;
}

,
 $attrBindFn_hidden_text: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 try{return wx.Util.iif(restData.current.fbaomilx==false,true,false)}catch(e){return ''} ;
}

,
 $roFn_restData3: function($data){
return true;
}

,
 $refPathFn_attachmentImage: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current._path ;
}

,
 $refPathFn_switch1: function({tableData4,restData,tableData1,restData1,tableData,params,$page,restData2,props,restData3}){
 return restData.current._path ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/tableData/tableData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"tableData1",
					"type":"array",
					"items":{
						"fns":$g_fns_tableData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"initData":[
					{
						"fid":"C7EC98301B8000016D559240B21DAA40"
					}
				],
				"options":{
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isMain":false,
					"autoMode":"load",
					"confirmDelete":true,
					"idColumn":"fid"
				},
				"id":"tableData1",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData2",
					"type":"array",
					"items":{
						"fns":$g_fns_restData2,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData2",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/tableData/tableData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"tableData",
					"type":"array",
					"items":{
						"fns":$g_fns_tableData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fzhuangtai":{
								"define":"fzhuangtai",
								"label":"状态",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"initData":[
					{
						"fid":"C7ECA056E4800001FF3FD5B0E7701732",
						"fzhuangtai":""
					}
				],
				"options":{
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isMain":false,
					"autoMode":"load",
					"confirmDelete":true,
					"idColumn":"fid"
				},
				"id":"tableData",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/tableData/tableData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"tableData4",
					"type":"array",
					"items":{
						"fns":$g_fns_tableData4,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"ffatieid":{
								"define":"ffatieid",
								"label":"发帖ID",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"initData":[
					{
						"fid":"C7FA724C9B6000015023144F1AACF8E0"
					}
				],
				"options":{
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isMain":false,
					"autoMode":"load",
					"confirmDelete":true,
					"idColumn":"fid"
				},
				"id":"tableData4",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"_key":{
								"type":"string"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fzhidingzt":{
								"default":$g_d_restData_fzhidingzt,
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"ffatiesj":{
								"default":$g_d_restData_ffatiesj,
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"_key":{
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"ffatier_yonghub_fnicheng":{
								"define":"fnicheng",
								"label":"发帖人-昵称",
								"type":"string",
								"table":"main_yonghub"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"fhuifus":{
								"default":$g_d_restData_fhuifus,
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"fbaomilx":{
								"default":$g_d_restData_fbaomilx,
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"new",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_yonghub",
							"columns":[
								{
									"field":"fnicheng",
									"name":"ffatier_yonghub_fnicheng",
									"label":"发帖人-昵称"
								}
							],
							"leftTable":"main_fatieb",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fyonghuid",
									"leftField":"ffatier"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData3",
					"type":"array",
					"items":{
						"fns":$g_fns_restData3,
						"type":"object",
						"key":"_key",
						"props":{
							"data9":{
								"readonly":"$data.getReadonly()",
								"define":"data9",
								"label":"地址",
								"type":"string"
							},
							"data17":{
								"readonly":"$data.getReadonly()",
								"define":"data17",
								"label":"生日",
								"type":"date"
							},
							"country":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"国家",
								"type":"string"
							},
							"data5":{
								"readonly":"$data.getReadonly()",
								"define":"data5",
								"label":"微博",
								"type":"string"
							},
							"gender":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"性别",
								"type":"string"
							},
							"avatarUrl":{
								"readonly":"$data.getReadonly()",
								"define":"avatarUrl",
								"label":"头像",
								"type":"string"
							},
							"data4":{
								"readonly":"$data.getReadonly()",
								"define":"data4",
								"label":"QQ",
								"type":"string"
							},
							"city":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"市",
								"type":"string"
							},
							"openId":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"openId",
								"type":"string"
							},
							"nickName":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"昵称",
								"type":"string"
							},
							"isLogined":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"是否登录",
								"type":"boolean"
							},
							"groups":{
								"readonly":"$data.getReadonly()",
								"define":"groups",
								"label":"群组",
								"type":"string"
							},
							"description":{
								"readonly":"$data.getReadonly()",
								"define":"description",
								"label":"备注",
								"type":"string"
							},
							"userName":{
								"readonly":"$data.getReadonly()",
								"define":"userName",
								"label":"登录名",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"province":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"省",
								"type":"string"
							},
							"phone":{
								"readonly":"$data.getReadonly()",
								"define":"phone",
								"label":"手机",
								"type":"string"
							},
							"name":{
								"readonly":"$data.getReadonly()",
								"define":"name",
								"label":"姓名",
								"type":"string"
							},
							"id":{
								"readonly":"$data.getReadonly()",
								"define":"id",
								"label":"id",
								"type":"string"
							},
							"email":{
								"readonly":"$data.getReadonly()",
								"define":"email",
								"label":"邮箱",
								"type":"string"
							},
							"group":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"群组",
								"type":"array"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/uaa/user",
					"autoMode":"",
					"defSlaves":[],
					"confirmDelete":true,
					"tableName":"uaa_user",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isAllColumns":true,
					"idColumn":"id"
				},
				"$roFn":"$roFn_restData3",
				"id":"restData3",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"$events":{
				"show":"$evtH_page_show"
			},
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"input1ValuechangeCallback"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/user/user'),
		"props":{
			"useOtherLogin":false,
			"autoUpdateUserInfo":false,
			"useSmsService":true,
			"data":"restData3",
			"loginSuccessHint":true,
			"useOpenid":true,
			"autoLoadUserInfo":true,
			"id":"user",
			"autoBindPhone":false,
			"appPath":"$UI/main",
			"logoutAfterToLogin":true,
			"autoLogin":false
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"code"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/input/input'),
		"props":{
			"$propName":"fbiaoti",
			"$refFn":"$refFn_input",
			"id":"input",
			"$refPathFn":"$refPathFn_input"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/textarea/textarea'),
		"props":{
			"$propName":"fneirong",
			"$refFn":"$refFn_textarea",
			"id":"textarea",
			"$refPathFn":"$refPathFn_textarea"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/attachmentImage/attachmentImage'),
		"props":{
			"count":"6",
			"$refPathFn":"$refPathFn_attachmentImage",
			"$propName":"ftupianfj",
			"$refFn":"$refFn_attachmentImage",
			"id":"attachmentImage"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view11"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view15"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view17"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"image1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/switch/switch'),
		"props":{
			"$propName":"fbaomilx",
			"$refFn":"$refFn_switch1",
			"id":"switch1",
			"$refPathFn":"$refPathFn_switch1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_text"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text3",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_text3"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/button/button'),
		"props":{
			"id":"button3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"发帖","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
