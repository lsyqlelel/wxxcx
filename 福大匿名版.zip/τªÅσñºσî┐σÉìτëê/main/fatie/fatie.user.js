import wx from '../../wxsys/lib/base/wx';
import PageImpl from "../../wxsys/lib/base/pageImpl";
var app = getApp();
export default class IndexPage extends PageImpl {
    constructor(...args) {
        super(...args);
    }
    addfatie() {
        
       this.comp('restData').newData({
                "defaultValues": [{
                    "ffatier": this.$compRefs.restData2.current.fyonghuid,
                    "fbiaoti": this.$compRefs.restData.current.fbiaoti,
                    "fneirong": this.$compRefs.restData.current.fneirong,
                    "ffatiesj": wx.Date.now(),
                    "fbaomilx": this.$compRefs.restData.current.fbaomilx,
                    "ftupianfj": this.$compRefs.restData.current.ftupianfj
                }]
            });
            this.comp('restData').saveData(undefined);
        wx.showToast({
            "title": "发帖成功！！",
            "mask": true
        });
        wx.navigateTo({
            "url": "$UI/main/wode/wode_ft.w"
        });
       
        }
       
        
    

}
