
import {createPageConfig} from './fatie.build';
Page(createPageConfig());
