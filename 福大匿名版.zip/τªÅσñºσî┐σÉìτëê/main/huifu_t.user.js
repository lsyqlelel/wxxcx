import wx from '../wxsys/lib/base/wx';
import PageImpl from "../wxsys/lib/base/pageImpl";var app = getApp();export default class IndexPage extends PageImpl {constructor(...args){super(...args);}

	
  code(){
        let regeneratorRuntime = require('../wxsys/comps/code/generator/runtime-module');
        "use strict";

        //当前函数的代码为自动生成,请勿手动修改!!!

        var code = function() {
            var _ref = _asyncToGenerator(regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                if (!(this.$compRefs.tableData.current.fneirong == "")) {
                                    _context.next = 6;
                                    break;
                                }

                                _context.next = 3;
                                return wx.showToast({
                                    "title": "内容不能为空"
                                });

                            case 3:
                                return _context.abrupt("return");

                            case 6:
                                if (this.$compRefs.tableData.current.fneirong == "") {
                                    _context.next = 13;
                                    break;
                                }

                                this.comp('restData1').newData({
                                    "defaultValues": [{
                                        "fzhutieid": this.params.param0,
                                        "fhuifuyhid": this.$compRefs.restData2.current.fyonghuid,
                                        "fhuifunr": this.$compRefs.tableData.current.fneirong,
                                        "fhuifusj": wx.Date.now(),
                                        "fdianzans": 0
                                    }, {
                                        "fzhutieid": this.params.param0,
                                        "fhuifuyhid": this.$compRefs.restData2.current.fyonghuid,
                                        "fhuifunr": this.$compRefs.tableData.current.fneirong,
                                        "fhuifusj": wx.Date.now(),
                                        "fdianzans": 0
                                    }]
                                });
                                this.comp('restData1').saveData(undefined);
                                this.comp('restData').setValue("fhuifus", this.$compRefs.restData.current.fhuifus + 1, undefined);
                                this.comp('restData').saveData(undefined);
                                this.comp('tableData').refreshData(undefined);
                                return _context.abrupt("return");

                            case 13:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            return function code() {
                return _ref.apply(this, arguments);
            };
        }();

        function _asyncToGenerator(fn) {
            return function() {
                var gen = fn.apply(this, arguments);
                return new Promise(function(resolve, reject) {
                    function step(key, arg) {
                        try {
                            var info = gen[key](arg);
                            var value = info.value;
                        } catch (error) {
                            reject(error);
                            return;
                        }
                        if (info.done) {
                            resolve(value);
                        } else {
                            return Promise.resolve(value).then(function(value) {
                                step("next", value);
                            }, function(err) {
                                step("throw", err);
                            });
                        }
                    }
                    return step("next");
                });
            };
        }
        return code.apply(this, arguments);
    }











	
  code1(){
        let regeneratorRuntime = require('../wxsys/comps/code/generator/runtime-module');
        "use strict";

        //当前函数的代码为自动生成,请勿手动修改!!!

        function code() {
            if (this.$compRefs.tableData1.current.fshouzangzt == "") {
                this.comp('tableData1').setValue("fshouzangzt", 1, undefined);
                return;
            } else if (!(this.$compRefs.tableData1.current.fshouzangzt == "")) {
                this.comp('tableData1').setValue("fshouzangzt", 0, undefined);
                return;
            }
        }
        return code.apply(this, arguments);
    }










	
  icon8TapCallback(){

	}





















	
  icon7TapCallback(event){
        let regeneratorRuntime = require('../wxsys/comps/code/generator/runtime-module');
        "use strict";

        //当前函数的代码为自动生成,请勿手动修改!!!

        function code(event) {
            this.comp('restData3').newData({
                "defaultValues": [{
                    "fshouzangr": this.$compRefs.restData2.current.fyonghuid,
                    "fguanzhunrid": this.params.param0,
                    "fshouzangbt": this.$compRefs.restData.current.fbiaoti,
                    "fhuifus": this.$compRefs.restData.current.fhuifus,
                    "ffatiesj": this.$compRefs.restData3.current.ffatiesj
                }]
            });
            this.comp('restData3').saveData(undefined);
            this.comp('restData').setValue("fguanzhuzt", 1, undefined);
            this.comp('restData').saveData(undefined);
            return;
        }
        return code.apply(this, arguments);
    }





























	
  code3(){
        /*
        //当前函数的代码为自动生成,请勿手动修改!!!

         function code(){
        this.comp('restData').setValue("fguanzhuzt",0,undefined);
        this.comp('restData').saveData(undefined);
        var delete = this.comp('restData3').find(["fshouzangr","fguanzhunrid"],[this.$compRefs.restData2.current.fyonghuid,this.params.param0],undefined,undefined,undefined);
        this.comp('restData3').deleteData(delete[0],undefined);
        this.comp('restData3').saveData(undefined);
        return ;
        }

        */
    }




































	
  code2(){
        let regeneratorRuntime = require('../wxsys/comps/code/generator/runtime-module');
        "use strict";

        //当前函数的代码为自动生成,请勿手动修改!!!

        function code() {
            this.comp('restData3').newData({
                "defaultValues": [{
                    "fshouzangr": this.$compRefs.restData2.current.fyonghuid,
                    "fguanzhunrid": this.params.param0,
                    "fshouzangbt": this.$compRefs.restData.current.fbiaoti,
                    "fhuifus": this.$compRefs.restData.current.fhuifus,
                    "ffatiesj": this.$compRefs.restData.current.ffatiesj
                }]
            });
            this.comp('restData3').saveData(undefined);
            this.comp('restData').setValue("fguanzhuzt", 1, undefined);
            this.comp('restData').saveData(undefined);
            return;
        }
        return code.apply(this, arguments);
    }





































	}
