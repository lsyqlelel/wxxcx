
import {createPageConfig} from './index.build';
Page(createPageConfig());
