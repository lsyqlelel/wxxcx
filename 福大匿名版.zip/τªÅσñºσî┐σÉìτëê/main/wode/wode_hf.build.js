import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './wode_hf.user';

 var $g_fns_restData3 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData2 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/list/list'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $items_list: function({listindex,restData1,params,$page,restData2,props,restData3,listitem}){
 return restData1.value ;
}

,$evtH_list_tap: function({listindex,$event,$data,restData1,$item,params,$page,restData2,props,restData3,listitem}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/huifu_t.w"};
	args.params={"param0":listitem.fzhutieid,"param1":undefined};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('redirectTo', args, $$$args);

}

,
 $filter__system1__restData2: function({isNotNull,$$dataObj,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,restData2,props,restData3,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('ffatier',restData3.current.fyonghuid/*{"dependencies":["restData3"]}*/, $$dataObj);
 ;
}

,
 $filter__system1__restData1: function({isNotNull,$$dataObj,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,restData2,props,restData3,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('fhuifuyhid',restData3.current.fyonghuid/*{"dependencies":["restData3"]}*/, $$dataObj);
 ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData3",
					"type":"array",
					"items":{
						"fns":$g_fns_restData3,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData3",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData2",
					"type":"array",
					"items":{
						"fns":$g_fns_restData2,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"_key":{
								"type":"string"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"depends":[
						"restData3"
					],
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享发帖数据"
					},
					"idColumn":"fid"
				},
				"id":"restData2",
				"filters":{
					"_system1_":[
						"$filter__system1__restData2"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[
						{
							"name":"fhuifusj",
							"type":0
						}
					],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fhuifuyhid":{
								"define":"fhuifuyhid",
								"label":"回复用户ID",
								"type":"string"
							},
							"fdianzans":{
								"define":"fdianzans",
								"label":"点赞数",
								"type":"integer"
							},
							"fhuifusj":{
								"define":"fhuifusj",
								"label":"回复时间",
								"type":"datetime"
							},
							"fzhutieid_fatieb_ffatiesj":{
								"define":"ffatiesj",
								"label":"主帖ID-发帖时间",
								"type":"datetime",
								"table":"main_fatieb"
							},
							"fhuifunr":{
								"define":"fhuifunr",
								"label":"回复内容",
								"type":"string"
							},
							"fzhutieid_fatieb_fneirong":{
								"define":"fneirong",
								"label":"主帖ID-内容",
								"type":"string",
								"table":"main_fatieb"
							},
							"fzhutieid_fatieb_fhuifus":{
								"define":"fhuifus",
								"label":"主帖ID-回复数",
								"type":"integer",
								"table":"main_fatieb"
							},
							"fzhutieid":{
								"define":"fzhutieid",
								"label":"主帖ID",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"fzhutieid_fatieb_fbiaoti":{
								"define":"fbiaoti",
								"label":"主帖ID-标题",
								"type":"string",
								"table":"main_fatieb"
							}
						}
					}
				},
				"options":{
					"depends":[
						"restData3"
					],
					"isMain":false,
					"className":"/main/huifub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_huifub",
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_fatieb",
							"columns":[
								{
									"field":"fbiaoti",
									"name":"fzhutieid_fatieb_fbiaoti",
									"label":"主帖ID-标题"
								},
								{
									"field":"fneirong",
									"name":"fzhutieid_fatieb_fneirong",
									"label":"主帖ID-内容"
								},
								{
									"field":"ffatiesj",
									"name":"fzhutieid_fatieb_ffatiesj",
									"label":"主帖ID-发帖时间"
								},
								{
									"field":"fhuifus",
									"name":"fzhutieid_fatieb_fhuifus",
									"label":"主帖ID-回复数"
								}
							],
							"leftTable":"main_huifub",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fid",
									"leftField":"fzhutieid"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{
					"_system1_":[
						"$filter__system1__restData1"
					]
				}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list",
			"item":"listitem",
			"autoRefresh":true,
			"dataId":"restData1",
			"$template":[],
			"autoLoadNextPage":true,
			"index":"listindex",
			"id":"list",
			"items":"restData1.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"我的回复","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
