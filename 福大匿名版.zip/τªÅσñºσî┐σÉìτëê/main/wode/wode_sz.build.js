import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './wode_sz.user';

 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';
import '../../wxsys/comps/image/image'; 
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/input/input'; 
import '../../wxsys/comps/button/button'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/popOver/popOver'; 
import '../../wxsys/comps/wrapper/wrapper'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/attachmentImage/attachmentImage'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $refPathFn_input: function({restData,params,$page,props}){
 return restData.current._path ;
}

,
 $refFn_attachmentImage: function({restData,params,$page,props}){
 return restData.current.fxiugaitx ;
}

,$evtH_row_tap: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('popOver',$event.source).executeOperation('show', args, $$$args);

}

,$evtH_popOver_show: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	args={"col":"fxiugaitx","item":"restData.current.fxiugaitx","data":"restData"};
	args.row=restData.current;
	args.value=null;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);

}

,
 $imageUrlFn_image: function({restData,params,$page,props}){
 return restData.current.ftouxiang ;
}

,
 $refFn_input: function({restData,params,$page,props}){
 return restData.current.fsuozaid ;
}

,$evtH_row1_tap: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('popOver1',$event.source).executeOperation('show', args, $$$args);

}

,$evtH_row3_tap: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('popOver3',$event.source).executeOperation('show', args, $$$args);

}

,$evtH_button_tap: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"ftouxiang","item":"restData.current.ftouxiang","data":"restData"};
	args.row=restData.current;
	args.value=restData.current.fxiugaitx;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"data":"restData"};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('saveData', args, $$$args);
}()).then(() => {
	let args={};
	args={"url":"$UI/main/wode.w"};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('navigateTo', args, $$$args);
});
});

}

,
 $refFn_input2: function({restData,params,$page,props}){
 return restData.current.fxingbie ;
}

,
 $attrBindFn_text_text2: function({restData,params,$page,props}){
 try{return wx.Util.iif(restData.current.fxingbie!="",restData.current.fxingbie,"请输入")}catch(e){return ''} ;
}

,
 $refFn_input1: function({restData,params,$page,props}){
 return restData.current.fyouxiang ;
}

,
 $attrBindFn_text_text4: function({restData,params,$page,props}){
 try{return wx.Util.iif(restData.current.fsuozaid!="",restData.current.fsuozaid,"请输入")}catch(e){return ''} ;
}

,$evtH_popOver_hide: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	args={"data":"restData"};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('saveData', args, $$$args);

}

,
 $attrBindFn_text_text6: function({restData,params,$page,props}){
 try{return wx.Util.iif(restData.current.fyouxiang!="",restData.current.fyouxiang,"请输入")}catch(e){return ''} ;
}

,$evtH_row2_tap: function({$event,$data,restData,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('popOver2',$event.source).executeOperation('show', args, $$$args);

}

,
 $refPathFn_input2: function({restData,params,$page,props}){
 return restData.current._path ;
}

,
 $refPathFn_input1: function({restData,params,$page,props}){
 return restData.current._path ;
}

,
 $refPathFn_attachmentImage: function({restData,params,$page,props}){
 return restData.current._path ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/popOver/popOver'),
		"props":{
			"$events":{
				"hide":"$evtH_popOver_hide",
				"show":"$evtH_popOver_show"
			},
			"id":"popOver"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view2"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/attachmentImage/attachmentImage'),
		"props":{
			"count":"1",
			"$refPathFn":"$refPathFn_attachmentImage",
			"statics":"true",
			"$propName":"fxiugaitx",
			"$refFn":"$refFn_attachmentImage",
			"id":"attachmentImage"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view12"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"default1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view16"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view25"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view27"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"image1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/popOver/popOver'),
		"props":{
			"id":"popOver1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view19"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/input/input'),
		"props":{
			"$propName":"fxingbie",
			"$refFn":"$refFn_input2",
			"id":"input2",
			"$refPathFn":"$refPathFn_input2"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/popOver/popOver'),
		"props":{
			"id":"popOver2"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view21"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/input/input'),
		"props":{
			"$propName":"fsuozaid",
			"$refFn":"$refFn_input",
			"id":"input",
			"$refPathFn":"$refPathFn_input"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/popOver/popOver'),
		"props":{
			"id":"popOver3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view23"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/input/input'),
		"props":{
			"$propName":"fyouxiang",
			"$refFn":"$refFn_input1",
			"id":"input1",
			"$refPathFn":"$refPathFn_input1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/image/image'),
		"props":{
			"$urlFn":"$imageUrlFn_image",
			"id":"image"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text2",
			"$attrBindFns":{
				"text":"$attrBindFn_text_text2"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row2"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text4",
			"$attrBindFns":{
				"text":"$attrBindFn_text_text4"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text6",
			"$attrBindFns":{
				"text":"$attrBindFn_text_text6"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/button/button'),
		"props":{
			"id":"button"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"我的设置","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
