
import {createPageConfig} from './wode_sc.build';
Page(createPageConfig());
