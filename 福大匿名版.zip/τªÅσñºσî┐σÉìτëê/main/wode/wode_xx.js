
import {createPageConfig} from './wode_xx.build';
Page(createPageConfig());
