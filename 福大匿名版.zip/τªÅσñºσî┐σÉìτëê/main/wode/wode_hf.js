
import {createPageConfig} from './wode_hf.build';
Page(createPageConfig());
