
import {createPageConfig} from './wode_ft.build';
Page(createPageConfig());
