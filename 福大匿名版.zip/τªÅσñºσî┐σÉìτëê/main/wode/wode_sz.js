
import {createPageConfig} from './wode_sz.build';
Page(createPageConfig());
