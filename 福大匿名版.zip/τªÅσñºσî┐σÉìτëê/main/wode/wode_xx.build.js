import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './wode_xx.user';

 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/list/list'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $items_list: function({listindex,restData,params,$page,props,listitem}){
 return restData.value ;
}

,
 $attrBindFn_hidden_row: function({restData,params,$page,props}){
 try{return wx.Util.iif(restData.current.fid==null,false,true)}catch(e){return ''} ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"fshijian":{
								"define":"fshijian",
								"label":"时间",
								"type":"datetime"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/jitonggg",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_jitonggg",
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"row",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_row"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list",
			"item":"listitem",
			"autoRefresh":true,
			"dataId":"restData",
			"$template":[],
			"autoLoadNextPage":true,
			"index":"listindex",
			"id":"list",
			"items":"restData.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"我的消息","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
