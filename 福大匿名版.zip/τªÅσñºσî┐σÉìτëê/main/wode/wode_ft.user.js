import wx from '../../wxsys/lib/base/wx';
import PageImpl from "../../wxsys/lib/base/pageImpl";var app = getApp();export default class IndexPage extends PageImpl {constructor(...args){super(...args);}
// hh(e){
//     this.comp("tableData").setValue("fhh",1);
//     this.settimeout11();
// }
// mm(e){
//     this.comp("tableData").setValue("fmm",1);
//     this.settimeout11();
// }
//  settimeout11(e) {
//      var controltime = wx.DateTimeUtilFn.fromNowSeconds(this.$compRefs.restData.current.ffatiesj);
//         var controltimeH = parseInt(controltime / 3600);
//         var controltimeM = parseInt((controltime % 3600) / 60);
//         var controltimeS = controltime % 60;
//         this.comp("restData").setValue("fdaojis", controltimeH);
//         this.comp("restData").setValue("fdaojif", controltimeM);
//         this.comp("restData").setValue("fdaojim", controltimeS);
//         var daojis = wx.DateTimeUtilFn.fromNowSeconds(this.$compRefs.restData.current.fdaojis);                
//         var daojish = parseInt(daojis / 3600);
//         var daojism = parseInt((daojis % 3600) / 60);
//         var daojiss = daojis % 60;
//         this.comp("restData").setValue("fdingshis", daojish);
//         this.comp("restData").setValue("fshishis", daojism);
//         this.comp("restData").setValue("fdingshim", daojiss);
//         if (daojish <= 0 && daojism <= 0 && daojiss <= 0) {
//             var jieguosj = parseInt(wx.DateTimeUtilFn.fromNowSeconds(this.$compRefs.restData.current.ffatiesj + this.$compRefs.restData.fdaojis -this.$compRefs.restData.current.ffatiesj) / 60 / 3600) + 1;
//             var jieguosj=controltime+3600-
//             this.comp("restData").setValue("fshijianjg", jieguosj);
//             this.comp("restData").saveData();

//         }
//         if (this.$compRefs.restData.current.fshijianjg <= 0) {
//             this.comp("timer").stop();
//         }
//     }

}


// // data2Event(e){
//         this.comp("tableData").setValue("fdata2",1);
//         this.comp("tableData").setValue("fzuihou",this.$compRefs.restData2.current.fzuihouxyr);
//         this.TimeIntervalLength();
//     }
//     data4Event(e){
//         this.comp("tableData").setValue("fdata4",1);
//         this.TimeIntervalLength();
//     }
//     TimeIntervalLength() {
//         var zuihou = this.comp("tableData").getValue("fzuihou");
//         // debugger;
//         var data2 = this.comp("tableData").getValue("fdata2");
//         var data4 = this.comp("tableData").getValue("fdata4");
//         if(data2 == 1 && data4 == 1){
//             var controltime = wx.DateTimeUtilFn.fromNowSeconds(zuihou);
//             var upgradetime = this.$compRefs.restData4.current.fzuixiaots * 24 * 3600 - controltime;
//             var upgradetimeH = parseInt(upgradetime / 3600);
//             var upgradetimeM = parseInt((upgradetime % 3600) / 60);
//             var upgradetimeS = upgradetime % 60;
//             this.comp("restData2").setValue("fshengjiszs", upgradetimeH);
//             this.comp("restData2").setValue("fshengjiszf", upgradetimeM);
//             this.comp("restData2").setValue("fshengjiszm", upgradetimeS);

//             if(upgradetimeH <= 0&&upgradetimeM <= 0 && upgradetimeS <= 0){
//                 //进入下一级别
//                 var yjyts = parseInt(wx.DateTimeUtilFn.fromNowSeconds(zuihou) / 3600 / 24) + 1;
//                 //控烟计划表
//                 this.comp("restData2").setValue("fjieyants",yjyts);
//                 this.comp("restData2").saveData();
//                 this.comp("restData4").refreshData();
//                 this.comp("restData").refreshData();
//             }
//             if(this.$compRefs.restData2.current.fjieyants<=0||this.$compRefs.restData2.current.fjieyants>=136){
//                 this.comp("timer").stop();
//             }
//         }
