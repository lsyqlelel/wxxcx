import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './wode_ft.user';

 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/list/list'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/wrapper/wrapper'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $items_list: function({listindex,restData,restData1,params,$page,props,listitem}){
 return restData.value ;
}

,
 $attrBindFn_hidden_view: function({listindex,restData,restData1,params,$page,props,listitem}){
 try{return wx.Util.iif(restData.current.fid=="",false,true)}catch(e){return ''} ;
}

,$evtH_list_tap: function({listindex,$event,$data,restData,restData1,$item,params,$page,props,listitem}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/huifu_t.w"};
	args.params={"param0":listitem.fid,"param1":undefined};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('redirectTo', args, $$$args);

}

,$evtH_page_show: function({$event,$data,restData,restData1,$item,params,$page,props}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('page',$event.source).executeOperation('refresh', args, $$$args);

}

,
 $filter__system1__restData: function({isNotNull,$$dataObj,restData,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,props,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('ffatier',restData1.current.fyonghuid/*{"dependencies":["restData1"]}*/, $$dataObj);
 ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[
						{
							"name":"ffatiesj",
							"type":0
						}
					],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"_key":{
								"type":"string"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"depends":[
						"restData1"
					],
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享发帖数据"
					},
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{
					"_system1_":[
						"$filter__system1__restData"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":-1,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"$events":{
				"show":"$evtH_page_show"
			},
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list",
			"item":"listitem",
			"autoRefresh":true,
			"dataId":"restData",
			"$template":[],
			"autoLoadNextPage":true,
			"index":"listindex",
			"id":"list",
			"items":"restData.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_view"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"我的发帖","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
