import wx from '../../wxsys/lib/base/wx';
import _createPageConfig from '../../wxsys/lib/base/createPageConfig';
import PageClass from './wode_sc.user';

 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData2 = {
		get _userdata(){
			return {

			};
		}
}; 


import '../../wxsys/comps/wrapper/wrapper';
import '../../wxsys/comps/image/image'; 
import '../../wxsys/comps/commonOperation/commonOperation'; 
import '../../wxsys/comps/list/list'; 
import '../../wxsys/comps/restData/restData'; 
import '../../wxsys/comps/page/page'; 
import '../../wxsys/comps/wrapper/wrapper'; 
import '../../wxsys/comps/toptips/toptips'; 
import '../../wxsys/comps/loading/loading'; 
import '../../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $items_list: function({listindex,restData,restData1,params,$page,restData2,props,listitem}){
 return restData2.value ;
}

,
 $attrBindFn_hidden_view: function({listindex,restData,restData1,params,$page,restData2,props,listitem}){
 try{return wx.Util.iif(restData2.count()==0,false,true)}catch(e){return ''} ;
}

,
 $attrBindFn_text_text4: function({listindex,restData,restData1,$item,params,$page,restData2,props,listitem}){
 try{return wx.Util.iif(listitem.fguanzhunrid_fatieb_fbaomilx=="0",listitem.ffatier_yonghub_fnicheng,"匿名用户")}catch(e){return ''} ;
}

,$evtH_list_tap: function({listindex,$event,$data,restData,restData1,$item,params,$page,restData2,props,listitem}){
let $$$args = arguments[0];
	let args={};
	args={"url":"$UI/main/huifu_t.w"};
	args.params={"param0":listitem.fguanzhunrid,"param1":undefined};
	return $page.$compByCtx('wxapi',$event.source).executeOperation('redirectTo', args, $$$args);

}

,$evtH_page_show: function({$event,$data,restData,restData1,$item,params,$page,restData2,props}){
let $$$args = arguments[0];
	let args={};
	args={"force":"true"};
	return $page.$compByCtx('restData',$event.source).executeOperation('refresh', args, $$$args);

}

,
 $filter__system1__restData: function({isNotNull,$$dataObj,restData,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,restData2,props,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('ffatier',restData1.current.fyonghuid/*{"dependencies":["restData1"]}*/, $$dataObj);
 ;
}

,
 $imageUrlFn_image: function({listindex,restData,restData1,$item,params,$page,restData2,props,listitem}){
 return listitem.ffatier_yonghub_ftouxiang ;
}

,
 $filter__system1__restData2: function({isNotNull,$$dataObj,restData,like,nlike,RBRAC,lt,inn,restData1,is,params,eq,gt,restData2,props,LBRAC,not,isNull,gte,ilike,neq,lte,$page,nilike}){
 	return eq('fshouzangr',restData1.current.fyonghuid/*{"dependencies":["restData1"]}*/, $$dataObj);
 ;
}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"_key":{
								"type":"string"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"depends":[
						"restData1"
					],
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享发帖数据"
					},
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{
					"_system1_":[
						"$filter__system1__restData"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData2",
					"type":"array",
					"items":{
						"fns":$g_fns_restData2,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fguanzhunrid_fatieb_fbaomilx":{
								"define":"fbaomilx",
								"label":"关注内容ID-保密类型",
								"type":"string",
								"table":"main_fatieb"
							},
							"fguanzhunrid":{
								"define":"fguanzhunrid",
								"label":"关注内容ID",
								"type":"string"
							},
							"fshouzangr":{
								"define":"fshouzangr",
								"label":"关注人ID",
								"type":"string"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fshouzangbt":{
								"define":"fshouzangbt",
								"label":"收藏标题",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"ffatier_yonghub_ftouxiang":{
								"define":"ftouxiang",
								"label":"发帖人-头像",
								"type":"string",
								"table":"main_yonghub"
							},
							"ffatier_yonghub_fnicheng":{
								"define":"fnicheng",
								"label":"发帖人-昵称",
								"type":"string",
								"table":"main_yonghub"
							},
							"fguanzhunrid_fatieb_fhuifus":{
								"define":"fhuifus",
								"label":"关注内容ID-回复数",
								"type":"integer",
								"table":"main_fatieb"
							},
							"fguanzhunrid_fatieb_fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注内容ID-关注状态",
								"type":"integer",
								"table":"main_fatieb"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"fguanzhunrid_fatieb_fid":{
								"define":"fid",
								"label":"关注内容ID-主键",
								"type":"string",
								"table":"main_fatieb"
							},
							"fguanzhunrid_fatieb_fbiaoti":{
								"define":"fbiaoti",
								"label":"关注内容ID-标题",
								"type":"string",
								"table":"main_fatieb"
							}
						}
					}
				},
				"options":{
					"depends":[
						"restData1"
					],
					"isMain":false,
					"className":"/main/shouzanglb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_shouzanglb",
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_fatieb",
							"columns":[
								{
									"field":"fid",
									"name":"fguanzhunrid_fatieb_fid",
									"label":"关注内容ID-主键"
								},
								{
									"field":"fbiaoti",
									"name":"fguanzhunrid_fatieb_fbiaoti",
									"label":"关注内容ID-标题"
								},
								{
									"field":"fbaomilx",
									"name":"fguanzhunrid_fatieb_fbaomilx",
									"label":"关注内容ID-保密类型"
								},
								{
									"field":"fhuifus",
									"name":"fguanzhunrid_fatieb_fhuifus",
									"label":"关注内容ID-回复数"
								},
								{
									"field":"fguanzhuzt",
									"name":"fguanzhunrid_fatieb_fguanzhuzt",
									"label":"关注内容ID-关注状态"
								}
							],
							"leftTable":"main_shouzanglb",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fid",
									"leftField":"fguanzhunrid"
								}
							]
						},
						{
							"rightTable":"main_yonghub",
							"columns":[
								{
									"field":"fnicheng",
									"name":"ffatier_yonghub_fnicheng",
									"label":"发帖人-昵称"
								},
								{
									"field":"ftouxiang",
									"name":"ffatier_yonghub_ftouxiang",
									"label":"发帖人-头像"
								}
							],
							"leftTable":"main_fatieb",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fyonghuid",
									"leftField":"ffatier"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData2",
				"filters":{
					"_system1_":[
						"$filter__system1__restData2"
					]
				}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"$events":{
				"show":"$evtH_page_show"
			},
			"id":"page"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list",
			"item":"listitem",
			"autoRefresh":true,
			"dataId":"restData2",
			"$template":[
				{
					"cls":wx.compClass('$UI/wxsys/comps/image/image'),
					"props":{
						"$urlFn":"$imageUrlFn_image",
						"id":"image"
					}
				},
				{
					"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
					"props":{
						"id":"text4",
						"$attrBindFns":{
							"text":"$attrBindFn_text_text4"
						}
					}
				}
			],
			"autoLoadNextPage":true,
			"index":"listindex",
			"id":"list",
			"items":"restData2.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"view",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_view"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"我的收藏","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
