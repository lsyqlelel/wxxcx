import wx from '../../wxsys/lib/base/wx';
import PageImpl from "../../wxsys/lib/base/pageImpl";var app = getApp();export default class IndexPage extends PageImpl {constructor(...args){super(...args);}}
