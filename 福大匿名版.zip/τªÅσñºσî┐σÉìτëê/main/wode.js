
import {createPageConfig} from './wode.build';
Page(createPageConfig());
