
import {createPageConfig} from './huifu_t.build';
Page(createPageConfig());
