
import {createPageConfig} from './pinche.build';
Page(createPageConfig());
