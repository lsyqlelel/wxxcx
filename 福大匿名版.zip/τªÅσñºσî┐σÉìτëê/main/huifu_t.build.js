import wx from '../wxsys/lib/base/wx';
import _createPageConfig from '../wxsys/lib/base/createPageConfig';
import PageClass from './huifu_t.user';

 var $g_fns_restData2 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_tableData = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_tableData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData1 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData3 = {
		get _userdata(){
			return {

			};
		}
}; 


 var $g_fns_restData = {
		get _userdata(){
			return {

			};
		}
}; 


import '../wxsys/comps/wrapper/wrapper';

 var $g_fns_restData4 = {
		get _userdata(){
			return {
				data9: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data17: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				country: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data5: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				gender: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				avatarUrl: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				data4: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				city: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				openId: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				nickName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				isLogined: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				groups: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				description: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				userName: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				province: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				phone: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				name: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				id: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				email: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				},
				group: {
					readonly: 	function($self){
							try{
								let $data=$self.$data;
					 			return $data.getReadonly()
							}catch(_$e){
								return null;
							}
						}(this)
				}
			};
		}
}; 

import '../wxsys/comps/user/user'; 
import '../wxsys/comps/image/image'; 
import '../comp/imgshow/components/imgshow/imgshow'; 
import '../wxsys/comps/commonOperation/commonOperation'; 
import '../wxsys/comps/tableData/tableData'; 
import '../wxsys/comps/list/list'; 
import '../comp/like/components/like/like'; 
import '../wxsys/comps/restData/restData'; 
import '../wxsys/comps/input/input'; 
import '../wxsys/comps/button/button'; 
import '../wxsys/comps/code/code'; 
import '../wxsys/comps/page/page'; 
import '../wxsys/comps/wrapper/wrapper'; 
import '../wxsys/comps/share/share'; 
import '../wxsys/comps/toptips/toptips'; 
import '../wxsys/comps/loading/loading'; 
import '../wxsys/comps/wxApi/wxApi'; 
var methods = {

 $roFn_restData4: function($data){
return true;
}

,
 $refFn_imgshow: function({restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3}){
 return restData.current.ftupianfj ;
}

,
 $refPathFn_input: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 return tableData.current._path ;
}

,
 $refPathFn_imgshow: function({restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3}){
 return restData.current._path ;
}

,$evtH_restData1_saveCommit: function({$event,$data,restData,restData1,tableData,params,restData4,restData2,props,restData3,tableData1,$item,$page}){
let $$$args = arguments[0];
	let args={};
	args={"force":"true"};
	return $page.$compByCtx('restData1',$event.source).executeOperation('refresh', args, $$$args);

}

,
 $exprBinding_share_paramExpr: function({restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3}){
 return {"title":params.param0} ;
}

,
 $filter__system1__restData: function({restData,nlike,lt,restData1,restData4,restData2,restData3,not,tableData1,gte,neq,lte,$page,isNotNull,$$dataObj,like,RBRAC,inn,tableData,is,params,eq,gt,props,LBRAC,isNull,ilike,nilike}){
 	return eq('fid',params.param0, $$dataObj);
 ;
}

,
 $imageUrlFn_image: function({restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3}){
 return restData.current.ffatier_yonghub_ftouxiang ;
}

,
 $refFn_input: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 return tableData.current.fneirong ;
}

,$evtH_button3_tap: function({listindex,$event,$data,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('code',$event.source).executeOperation('exec', args, $$$args);

}

,
 $refPathFn_like: function({listindex,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
 return listitem._path ;
}

,$evtH_icon8_tap: function({listindex,$event,$data,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
let $$$args = arguments[0];
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"fguanzhuzt","item":"restData.current.fguanzhuzt","data":"restData"};
	args.row=restData.current;
	args.value=0;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
wx.OperationPromise.resolve(function(){
	let args={};
	args={"data":"restData"};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('saveData', args, $$$args);
}()).then(() => {
	let args={};
	args={"data":"restData3","force":"true"};
	args.filter=function($row){return wx.Util.iif($row.fguanzhunrid==params.param0,true,false);};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('deleteData', args, $$$args);
});
});

}

,
 $filter__system1__restData1: function({restData,nlike,lt,restData1,restData4,restData2,restData3,not,tableData1,gte,neq,lte,$page,isNotNull,$$dataObj,like,RBRAC,inn,tableData,is,params,eq,gt,props,LBRAC,isNull,ilike,nilike}){
 	return eq('fzhutieid',params.param0, $$dataObj);
 ;
}

,
 $items_list: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 return restData1.value ;
}

,
 $attrBindFn_hidden_icon8: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 try{return wx.Util.iif(restData.current.fguanzhuzt==1,false,true)}catch(e){return ''} ;
}

,
 $attrBindFn_hidden_icon7: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 try{return wx.Util.iif(restData.current.fguanzhuzt==1,true,false)}catch(e){return ''} ;
}

,
 $refFn_like: function({listindex,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
 return listitem.fdianzans ;
}

,
 $filterlist: function({listindex,restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3,listitem}){
 return listitem.fzhutieid  == restData.current.fid ;
}

,$evtH_icon7_tap: function({listindex,$event,$data,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
let $$$args = arguments[0];
	let args={};
	return $page.$compByCtx('code2',$event.source).executeOperation('exec', args, $$$args);

}

,
 $imageUrlFn_image2: function({listindex,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
 return listitem.fhuifuyhid_yonghub_ftouxiang ;
}

,
 $attrBindFn_text_text1: function({restData,tableData1,restData1,tableData,params,restData4,$page,restData2,props,restData3}){
 try{return wx.Util.iif(restData.current.fbaomilx!="1",restData.current.ffatier_yonghub_fnicheng,"匿名用户")}catch(e){return ''} ;
}

,$evtH_like_valuechange: function({listindex,$event,$data,restData,restData1,tableData,params,restData4,restData2,props,restData3,listitem,tableData1,$item,$page}){
let $$$args = arguments[0];
wx.OperationPromise.resolve(function(){
	let args={};
	args={"col":"fdianzans","item":"listitem.fdianzans"};
	args.row=listitem;
	args.value=$event.newValue;
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('setValue', args, $$$args);
}()).then(() => {
	let args={};
	args={"data":"restData1"};
	return $page.$compByCtx('commonOperation',$event.source).executeOperation('saveData', args, $$$args);
});

}

}
var template = [
	[
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData2",
					"type":"array",
					"items":{
						"fns":$g_fns_restData2,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fxingbie":{
								"define":"fxingbie",
								"label":"性别",
								"type":"string"
							},
							"fdianhua":{
								"define":"fdianhua",
								"label":"电话",
								"type":"string"
							},
							"ftouxiang":{
								"define":"ftouxiang",
								"label":"头像",
								"type":"string"
							},
							"fmingcheng":{
								"define":"fmingcheng",
								"label":"名称",
								"type":"string"
							},
							"fyouxiang":{
								"define":"fyouxiang",
								"label":"邮箱",
								"type":"string"
							},
							"fsuozaid":{
								"define":"fsuozaid",
								"label":"所在地",
								"type":"string"
							},
							"fyonghuid":{
								"define":"fyonghuid",
								"label":"用户ID",
								"type":"string"
							},
							"fxiugaitx":{
								"define":"fxiugaitx",
								"label":"修改头像",
								"type":"objectstorage"
							},
							"_key":{
								"type":"string"
							},
							"fnicheng":{
								"define":"fnicheng",
								"label":"昵称",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/yonghub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_yonghub",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"share":{
						"name":"共享用户表"
					},
					"idColumn":"fid"
				},
				"id":"restData2",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/tableData/tableData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"tableData",
					"type":"array",
					"items":{
						"fns":$g_fns_tableData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"initData":[
					{
						"fid":"C7ECDD0DF1B00001F91F1CD21FD812A3"
					}
				],
				"options":{
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isMain":false,
					"autoMode":"load",
					"confirmDelete":true,
					"idColumn":"fid"
				},
				"id":"tableData",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/tableData/tableData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"tableData1",
					"type":"array",
					"items":{
						"fns":$g_fns_tableData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fshifouxs":{
								"define":"fshifouxs",
								"label":"是否显示",
								"type":"integer"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"initData":[
					{
						"fid":"C7ED4B4405B00001BA431A70FFA04F50"
					}
				],
				"options":{
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isMain":false,
					"autoMode":"load",
					"confirmDelete":true,
					"idColumn":"fid"
				},
				"id":"tableData1",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[
						{
							"name":"fhuifusj",
							"type":0
						},
						{
							"name":"fdianzans",
							"type":0
						}
					],
					"keyItems":"_key",
					"id":"restData1",
					"type":"array",
					"items":{
						"fns":$g_fns_restData1,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fhuifuyhid":{
								"define":"fhuifuyhid",
								"label":"回复用户ID",
								"type":"string"
							},
							"fdianzans":{
								"define":"fdianzans",
								"label":"点赞数",
								"type":"integer"
							},
							"fhuifusj":{
								"define":"fhuifusj",
								"label":"回复时间",
								"type":"datetime"
							},
							"fhuifuyhid_yonghub_ftouxiang":{
								"define":"ftouxiang",
								"label":"回复用户ID-头像",
								"type":"string",
								"table":"main_yonghub"
							},
							"fhuifuyhid_yonghub_fnicheng":{
								"define":"fnicheng",
								"label":"回复用户ID-昵称",
								"type":"string",
								"table":"main_yonghub"
							},
							"fhuifunr":{
								"define":"fhuifunr",
								"label":"回复内容",
								"type":"string"
							},
							"fzhutieid":{
								"define":"fzhutieid",
								"label":"主帖ID",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"$events":{
					"saveCommit":"$evtH_restData1_saveCommit"
				},
				"options":{
					"isMain":false,
					"className":"/main/huifub",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_huifub",
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_yonghub",
							"columns":[
								{
									"field":"fnicheng",
									"name":"fhuifuyhid_yonghub_fnicheng",
									"label":"回复用户ID-昵称"
								},
								{
									"field":"ftouxiang",
									"name":"fhuifuyhid_yonghub_ftouxiang",
									"label":"回复用户ID-头像"
								}
							],
							"leftTable":"main_huifub",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fyonghuid",
									"leftField":"fhuifuyhid"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData1",
				"filters":{
					"_system1_":[
						"$filter__system1__restData1"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData3",
					"type":"array",
					"items":{
						"fns":$g_fns_restData3,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fguanzhunrid":{
								"define":"fguanzhunrid",
								"label":"关注内容ID",
								"type":"string"
							},
							"fshouzangr":{
								"define":"fshouzangr",
								"label":"关注人ID",
								"type":"string"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"fshouzangbt":{
								"define":"fshouzangbt",
								"label":"收藏标题",
								"type":"string"
							},
							"_key":{
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/shouzanglb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_shouzanglb",
					"confirmRefreshText":"",
					"allowEmpty":true,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"idColumn":"fid"
				},
				"id":"restData3",
				"filters":{}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData",
					"type":"array",
					"items":{
						"fns":$g_fns_restData,
						"type":"object",
						"key":"_key",
						"props":{
							"fid":{
								"define":"fid",
								"label":"主键",
								"type":"string"
							},
							"fzhidingzt":{
								"define":"fzhidingzt",
								"label":"置顶状态（置顶为0）",
								"type":"string"
							},
							"ftupianfj":{
								"define":"ftupianfj",
								"label":"图片附件",
								"type":"objectstorage"
							},
							"ffatiesj":{
								"define":"ffatiesj",
								"label":"发帖时间",
								"type":"datetime"
							},
							"_key":{
								"type":"string"
							},
							"fguanzhuzt":{
								"define":"fguanzhuzt",
								"label":"关注状态",
								"type":"integer"
							},
							"ffatier_yonghub_ftouxiang":{
								"define":"ftouxiang",
								"label":"发帖人-头像",
								"type":"string",
								"table":"main_yonghub"
							},
							"ffatier":{
								"define":"ffatier",
								"label":"发帖人",
								"type":"string"
							},
							"ffatier_yonghub_fnicheng":{
								"define":"fnicheng",
								"label":"发帖人-昵称",
								"type":"string",
								"table":"main_yonghub"
							},
							"fneirong":{
								"define":"fneirong",
								"label":"内容",
								"type":"string"
							},
							"fbiaoti":{
								"define":"fbiaoti",
								"label":"标题",
								"type":"string"
							},
							"fhuifus":{
								"define":"fhuifus",
								"label":"回复数",
								"type":"integer"
							},
							"fbaomilx":{
								"define":"fbaomilx",
								"label":"保密类型",
								"type":"string"
							},
							"fxuanzhongzt":{
								"define":"fxuanzhongzt",
								"label":"选中状态",
								"type":"string"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/main/fatieb",
					"autoMode":"load",
					"defSlaves":[],
					"url":"/dbrest",
					"confirmDelete":true,
					"tableName":"main_fatieb",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"join":[
						{
							"rightTable":"main_yonghub",
							"columns":[
								{
									"field":"fnicheng",
									"name":"ffatier_yonghub_fnicheng",
									"label":"发帖人-昵称"
								},
								{
									"field":"ftouxiang",
									"name":"ffatier_yonghub_ftouxiang",
									"label":"发帖人-头像"
								}
							],
							"leftTable":"main_fatieb",
							"type":"inner",
							"on":[
								{
									"fn":"eq",
									"rightField":"fyonghuid",
									"leftField":"ffatier"
								}
							]
						}
					],
					"idColumn":"fid"
				},
				"id":"restData",
				"filters":{
					"_system1_":[
						"$filter__system1__restData"
					]
				}
			}
		},
		{
			"cls":wx.compClass('$UI/wxsys/comps/restData/restData'),
			"props":{
				"schema":{
					"limit":20,
					"orderBy":[],
					"keyItems":"_key",
					"id":"restData4",
					"type":"array",
					"items":{
						"fns":$g_fns_restData4,
						"type":"object",
						"key":"_key",
						"props":{
							"data9":{
								"readonly":"$data.getReadonly()",
								"define":"data9",
								"label":"地址",
								"type":"string"
							},
							"data17":{
								"readonly":"$data.getReadonly()",
								"define":"data17",
								"label":"生日",
								"type":"date"
							},
							"country":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"国家",
								"type":"string"
							},
							"data5":{
								"readonly":"$data.getReadonly()",
								"define":"data5",
								"label":"微博",
								"type":"string"
							},
							"gender":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"性别",
								"type":"string"
							},
							"avatarUrl":{
								"readonly":"$data.getReadonly()",
								"define":"avatarUrl",
								"label":"头像",
								"type":"string"
							},
							"data4":{
								"readonly":"$data.getReadonly()",
								"define":"data4",
								"label":"QQ",
								"type":"string"
							},
							"city":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"市",
								"type":"string"
							},
							"openId":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"openId",
								"type":"string"
							},
							"nickName":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"昵称",
								"type":"string"
							},
							"isLogined":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"是否登录",
								"type":"boolean"
							},
							"groups":{
								"readonly":"$data.getReadonly()",
								"define":"groups",
								"label":"群组",
								"type":"string"
							},
							"description":{
								"readonly":"$data.getReadonly()",
								"define":"description",
								"label":"备注",
								"type":"string"
							},
							"userName":{
								"readonly":"$data.getReadonly()",
								"define":"userName",
								"label":"登录名",
								"type":"string"
							},
							"_key":{
								"type":"string"
							},
							"province":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"省",
								"type":"string"
							},
							"phone":{
								"readonly":"$data.getReadonly()",
								"define":"phone",
								"label":"手机",
								"type":"string"
							},
							"name":{
								"readonly":"$data.getReadonly()",
								"define":"name",
								"label":"姓名",
								"type":"string"
							},
							"id":{
								"readonly":"$data.getReadonly()",
								"define":"id",
								"label":"id",
								"type":"string"
							},
							"email":{
								"readonly":"$data.getReadonly()",
								"define":"email",
								"label":"邮箱",
								"type":"string"
							},
							"group":{
								"readonly":"$data.getReadonly()",
								"isCal":true,
								"define":"EXPRESS",
								"label":"群组",
								"type":"array"
							}
						}
					}
				},
				"options":{
					"isMain":false,
					"className":"/uaa/user",
					"autoMode":"",
					"defSlaves":[],
					"confirmDelete":true,
					"tableName":"uaa_user",
					"confirmRefreshText":"",
					"allowEmpty":false,
					"confirmDeleteText":"",
					"confirmRefresh":true,
					"isAllColumns":true,
					"idColumn":"id"
				},
				"$roFn":"$roFn_restData4",
				"id":"restData4",
				"filters":{}
			}
		}
	],
	{
		"cls":wx.compClass('$UI/wxsys/comps/page/page'),
		"props":{
			"id":"page",
			"params":{
				"param0":"String"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wxApi/wxApi'),
		"props":{
			"id":"wxapi"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/commonOperation/commonOperation'),
		"props":{
			"id":"commonOperation"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/loading/loading'),
		"props":{
			"loadingNum":0,
			"id":"_random1"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"code",
			"params":"[]"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"code1",
			"params":"[]"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/user/user'),
		"props":{
			"useOtherLogin":false,
			"autoUpdateUserInfo":false,
			"useSmsService":true,
			"data":"restData4",
			"loginSuccessHint":true,
			"useOpenid":true,
			"autoLoadUserInfo":true,
			"id":"user",
			"autoBindPhone":false,
			"appPath":"$UI/main",
			"logoutAfterToLogin":true,
			"autoLogin":false
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/share/share'),
		"props":{
			"id":"share",
			"$execute_paramExpr":"$exprBinding_share_paramExpr"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"code3",
			"params":"[]"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/code/code'),
		"props":{
			"id":"code2",
			"params":"[]"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/image/image'),
		"props":{
			"$urlFn":"$imageUrlFn_image",
			"id":"image"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"text1",
			"$attrBindFns":{
				"text":"$attrBindFn_text_text1"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/comp/imgshow/components/imgshow/imgshow'),
		"props":{
			"$propName":"ftupianfj",
			"$refFn":"$refFn_imgshow",
			"id":"imgshow",
			"$refPathFn":"$refPathFn_imgshow"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"image3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/list/list'),
		"props":{
			"$items":"$items_list",
			"item":"listitem",
			"autoRefresh":true,
			"dataId":"restData1",
			"$template":[
				{
					"cls":wx.compClass('$UI/wxsys/comps/image/image'),
					"props":{
						"$urlFn":"$imageUrlFn_image2",
						"id":"image2"
					}
				},
				{
					"cls":wx.compClass('$UI/comp/like/components/like/like'),
					"props":{
						"$propName":"fdianzans",
						"$refFn":"$refFn_like",
						"$events":{
							"valuechange":"$evtH_like_valuechange"
						},
						"textCount":"listitem.fdianzans",
						"id":"like",
						"$refPathFn":"$refPathFn_like",
						"attentionIcon":"e-commerce e-commerce-zan"
					}
				}
			],
			"$filter":"$filterlist",
			"autoLoadNextPage":true,
			"index":"listindex",
			"id":"list",
			"items":"restData1.value",
			"key":"_key"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/input/input'),
		"props":{
			"$propName":"fneirong",
			"$refFn":"$refFn_input",
			"id":"input",
			"$refPathFn":"$refPathFn_input"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/button/button'),
		"props":{
			"id":"button3"
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"icon7",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_icon7"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/wrapper/wrapper'),
		"props":{
			"id":"icon8",
			"$attrBindFns":{
				"hidden":"$attrBindFn_hidden_icon8"
			}
		}
	},
	{
		"cls":wx.compClass('$UI/wxsys/comps/toptips/toptips'),
		"props":{
			"id":"__toptips__"
		}
	}
];
export function createPageConfig(){
	return _createPageConfig(PageClass, template, methods, {"navigationBarBackgroundColor":"#6666bb","navigationBarTitleText":"回复贴","navigationBarTextStyle":"white"})
}
export function createPage(owner, pageid, props){
	var page = new PageClass(owner, props);
	page.$init(template, methods, pageid);
	return page;
}
