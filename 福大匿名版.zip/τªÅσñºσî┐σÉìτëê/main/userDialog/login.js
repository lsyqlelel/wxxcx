
import {createPageConfig} from './login.build';
Page(createPageConfig());
