
import {createPageConfig} from './changePassword.build';
Page(createPageConfig());
