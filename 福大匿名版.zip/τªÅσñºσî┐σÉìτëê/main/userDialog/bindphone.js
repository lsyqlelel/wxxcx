
import {createPageConfig} from './bindphone.build';
Page(createPageConfig());
