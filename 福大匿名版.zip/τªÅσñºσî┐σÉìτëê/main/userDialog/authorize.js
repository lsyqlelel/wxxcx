
import {createPageConfig} from './authorize.build';
Page(createPageConfig());
