
import {createPageConfig} from './forgetPassword.build';
Page(createPageConfig());
