import wx from '../../wxsys/lib/base/wx';
import PageImpl from "../../wxsys/comps/user/userDialog/user.user";
var app = getApp();
export default class EditPage extends PageImpl {
  constructor(...args){super(...args);}
}
