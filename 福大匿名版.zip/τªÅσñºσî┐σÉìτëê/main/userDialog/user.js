
import {createPageConfig} from './user.build';
Page(createPageConfig());
