
import {createPageConfig} from './register.build';
Page(createPageConfig());
